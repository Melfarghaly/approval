<?php

return [
    'name' => 'Repair',
    'module_version' => "0.8",
    'pid' => 6
];
